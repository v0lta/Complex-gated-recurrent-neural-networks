
# THIS FILE IS GENERATED FROM THEANO SETUP.PY
short_version = '0.9.0'
version = '0.9.0'
git_revision = 'c697eeab84e5b8a74908da654b66ec9eca4f1291'
full_version = '0.9.0.dev-%(git_revision)s' % {
    'git_revision': git_revision}
release = True

if not release:
    version = full_version
